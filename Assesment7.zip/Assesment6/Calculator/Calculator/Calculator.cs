﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Calculator : Form
    {
        //Booleans so the calculator knows what is going on in the equals stage
        //Also working total
        public double Total = double.MaxValue;
        public Boolean Plus = false;
        public Boolean Minus = false;
        public Boolean Times = false;
        public Boolean Divide = false;

        public Calculator()
        {
            InitializeComponent();
        }


        public void MathManager()
        {
            //Method resets all of these so that only 1 can ever be true
            Plus = false;
            Minus = false;
            Times = false;
            Divide = false;
        }

        public void Equals()
        {
            //equals method determines what kind of math is being done.
            try
            {
                if (Plus == true)
                {
                    Total = BasicMath.Class1.Add(Total, double.Parse(DisplayBox.Text));

                }
                if (Minus == true)
                {
                    Total = BasicMath.Class1.Sub(Total, double.Parse(DisplayBox.Text));

                }
                if (Times == true)
                {
                    Total = BasicMath.Class1.Multi(Total, double.Parse(DisplayBox.Text));
                }
                if (Divide == true)
                {
                    Total = BasicMath.Class1.Div(Total, double.Parse(DisplayBox.Text));
                }
                MathManager();  //reset booleans
                DisplayBox.Clear();     //clear previous content
                DisplayBox.Text = Total.ToString();     //display new content
            }
            catch (Exception)
            {
                DisplayBox.Clear();
                MessageBox.Show("Error!");
            }
        }

        //Following clicks all just update display
        private void OneBtn_Click(object sender, EventArgs e)
        {
            DisplayBox.Text += 1;
        }

        private void TwoBtn_Click(object sender, EventArgs e)
        {
            DisplayBox.Text += 2;
        }

        private void ThreeBtn_Click(object sender, EventArgs e)
        {
            DisplayBox.Text += 3;
        }

        private void FourBtn_Click(object sender, EventArgs e)
        {
            DisplayBox.Text += 4;
        }

        private void FiveBtn_Click(object sender, EventArgs e)
        {
            DisplayBox.Text += 5;
        }

        private void SixBtn_Click(object sender, EventArgs e)
        {
            DisplayBox.Text += 6;
        }

        private void SevenBtn_Click(object sender, EventArgs e)
        {
            DisplayBox.Text += 7;
        }

        private void EightBtn_Click(object sender, EventArgs e)
        {
            DisplayBox.Text += 8;
        }

        private void NineBtn_Click(object sender, EventArgs e)
        {
            DisplayBox.Text += 9;
        }

        private void ZeroBtn_Click(object sender, EventArgs e)
        {
            DisplayBox.Text += 0;
        }

        private void DotBtn_Click(object sender, EventArgs e)
        {
            if (DisplayBox.Text.Contains("."))
            {
                //Do nothing, this blocks the user from entering multiple '.'s
            }
            else
            {
                DisplayBox.Text += ".";
            }
        }

        private void ClearBtn_Click(object sender, EventArgs e)
        {
            //Clear the text box and reset total
            DisplayBox.Clear();
            Total = double.MaxValue;

        }

        private void PlusBtn_Click(object sender, EventArgs e)
        {
            if (Total != double.MaxValue)
            {
                //if Total != max value calculate the equation as some math has likely already been done.
                Equals();
            }
            else
            {   //over write 
                Total = double.Parse(DisplayBox.Text);
            }
            MathManager();
            Plus = true;
            DisplayBox.Clear();
            
            
        }

        private void MinusBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (Total != double.MaxValue)
                {
                    Equals();
                }
                else
                {
                    Total = double.Parse(DisplayBox.Text);
                }
                MathManager();
                Minus = true;
                DisplayBox.Clear();
            }
            catch (Exception)
            {
                //negative numbers
                DisplayBox.Text += "-";
            }
        }

        private void DivideBtn_Click(object sender, EventArgs e)
        {
            if (Total != double.MaxValue)
            {
                Equals();
            }
            else
            {
                Total = double.Parse(DisplayBox.Text);
            }
            MathManager();
            Divide = true;
            DisplayBox.Clear();
        }

        private void TimesBtn_Click(object sender, EventArgs e)
        {
            if (Total != double.MaxValue)
            {
                Equals();
            }
            else
            {
                Total = double.Parse(DisplayBox.Text);
            }
            MathManager();
            Times = true;
            DisplayBox.Clear();
        }

        private void EqualsBtn_Click(object sender, EventArgs e)
        {
            if (DisplayBox.Text == "")
            {
                //if display box is empty don't do anything, stops it from displaying max value when clicked before doing anything
            }
            else
            {
                Equals();
            }
        }

        private void TanBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (double.Parse(DisplayBox.Text) % 90 == 0)
                {
                    DisplayBox.Clear();
                    DisplayBox.Text = "Tan can not be divisible by 90";
                }
                else
                {
                    Total = Trig.Class1.tan(double.Parse(DisplayBox.Text));
                    //double result = Math.Tan(double.Parse(DisplayBox.Text));
                    DisplayBox.Clear();
                    DisplayBox.Text = Total.ToString();
                }
            }
            catch (Exception)
            {
                //Do nothing
            }
        }

        private void SinBtn_Click(object sender, EventArgs e)
        {
            try
            {
                Total = Trig.Class1.sin(double.Parse(DisplayBox.Text));
                DisplayBox.Clear();
                DisplayBox.Text = Total.ToString();
            }
            catch (Exception)
            {
                //Do nothing
            }
        }

        private void CosBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (double.Parse(DisplayBox.Text) == 90)
                {
                    DisplayBox.Clear();
                    DisplayBox.Text = "0";
                }
                else
                {
                    Total = Trig.Class1.cos(double.Parse(DisplayBox.Text));
                    DisplayBox.Clear();
                    DisplayBox.Text = Total.ToString();
                }
            }
            catch (Exception)
            {
                //Do nothing
            }
        }

        private void SQRTBtn_Click(object sender, EventArgs e)
        {
            try
            {
                Total = BasicAlgebra.Class1.SquareRoot(double.Parse(DisplayBox.Text));
                DisplayBox.Clear();
                DisplayBox.Text = Total.ToString();
            }
            catch (Exception)
            {
                //Do nothing
            }
        }

        private void CubeRTBtn_Click(object sender, EventArgs e)
        {
            try
            {
                Total = BasicAlgebra.Class1.CubeRoot(double.Parse(DisplayBox.Text));
                DisplayBox.Clear();
                DisplayBox.Text = Total.ToString();
            }
            catch (Exception)
            {
                //Do nothing
            }
        }

        private void InvBtn_Click(object sender, EventArgs e)
        {
            try
            {
                Total = BasicAlgebra.Class1.Inverse(double.Parse(DisplayBox.Text));
                DisplayBox.Clear();
                DisplayBox.Text = Total.ToString();
            }
            catch (Exception)
            {
                //Do nothing
            }
        }
    }
}
