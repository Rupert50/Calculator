﻿namespace Calculator
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DisplayBox = new System.Windows.Forms.TextBox();
            this.SQRTBtn = new System.Windows.Forms.Button();
            this.CubeRTBtn = new System.Windows.Forms.Button();
            this.InvBtn = new System.Windows.Forms.Button();
            this.TanBtn = new System.Windows.Forms.Button();
            this.SinBtn = new System.Windows.Forms.Button();
            this.CosBtn = new System.Windows.Forms.Button();
            this.SevenBtn = new System.Windows.Forms.Button();
            this.EightBtn = new System.Windows.Forms.Button();
            this.NineBtn = new System.Windows.Forms.Button();
            this.FourBtn = new System.Windows.Forms.Button();
            this.FiveBtn = new System.Windows.Forms.Button();
            this.SixBtn = new System.Windows.Forms.Button();
            this.OneBtn = new System.Windows.Forms.Button();
            this.TwoBtn = new System.Windows.Forms.Button();
            this.ThreeBtn = new System.Windows.Forms.Button();
            this.ClearBtn = new System.Windows.Forms.Button();
            this.ZeroBtn = new System.Windows.Forms.Button();
            this.DotBtn = new System.Windows.Forms.Button();
            this.PlusBtn = new System.Windows.Forms.Button();
            this.MinusBtn = new System.Windows.Forms.Button();
            this.DivideBtn = new System.Windows.Forms.Button();
            this.TimesBtn = new System.Windows.Forms.Button();
            this.EqualsBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // DisplayBox
            // 
            this.DisplayBox.Location = new System.Drawing.Point(13, 13);
            this.DisplayBox.Name = "DisplayBox";
            this.DisplayBox.ReadOnly = true;
            this.DisplayBox.Size = new System.Drawing.Size(237, 20);
            this.DisplayBox.TabIndex = 0;
            // 
            // SQRTBtn
            // 
            this.SQRTBtn.Location = new System.Drawing.Point(13, 40);
            this.SQRTBtn.Name = "SQRTBtn";
            this.SQRTBtn.Size = new System.Drawing.Size(56, 23);
            this.SQRTBtn.TabIndex = 1;
            this.SQRTBtn.Text = "SQRT";
            this.SQRTBtn.UseVisualStyleBackColor = true;
            this.SQRTBtn.Click += new System.EventHandler(this.SQRTBtn_Click);
            // 
            // CubeRTBtn
            // 
            this.CubeRTBtn.Location = new System.Drawing.Point(75, 41);
            this.CubeRTBtn.Name = "CubeRTBtn";
            this.CubeRTBtn.Size = new System.Drawing.Size(58, 23);
            this.CubeRTBtn.TabIndex = 2;
            this.CubeRTBtn.Text = "CubeRT";
            this.CubeRTBtn.UseVisualStyleBackColor = true;
            this.CubeRTBtn.Click += new System.EventHandler(this.CubeRTBtn_Click);
            // 
            // InvBtn
            // 
            this.InvBtn.Location = new System.Drawing.Point(139, 41);
            this.InvBtn.Name = "InvBtn";
            this.InvBtn.Size = new System.Drawing.Size(51, 23);
            this.InvBtn.TabIndex = 3;
            this.InvBtn.Text = "Inv";
            this.InvBtn.UseVisualStyleBackColor = true;
            this.InvBtn.Click += new System.EventHandler(this.InvBtn_Click);
            // 
            // TanBtn
            // 
            this.TanBtn.Location = new System.Drawing.Point(13, 70);
            this.TanBtn.Name = "TanBtn";
            this.TanBtn.Size = new System.Drawing.Size(56, 23);
            this.TanBtn.TabIndex = 4;
            this.TanBtn.Text = "Tan";
            this.TanBtn.UseVisualStyleBackColor = true;
            this.TanBtn.Click += new System.EventHandler(this.TanBtn_Click);
            // 
            // SinBtn
            // 
            this.SinBtn.Location = new System.Drawing.Point(75, 70);
            this.SinBtn.Name = "SinBtn";
            this.SinBtn.Size = new System.Drawing.Size(58, 23);
            this.SinBtn.TabIndex = 5;
            this.SinBtn.Text = "Sin";
            this.SinBtn.UseVisualStyleBackColor = true;
            this.SinBtn.Click += new System.EventHandler(this.SinBtn_Click);
            // 
            // CosBtn
            // 
            this.CosBtn.Location = new System.Drawing.Point(139, 70);
            this.CosBtn.Name = "CosBtn";
            this.CosBtn.Size = new System.Drawing.Size(51, 23);
            this.CosBtn.TabIndex = 6;
            this.CosBtn.Text = "Cos";
            this.CosBtn.UseVisualStyleBackColor = true;
            this.CosBtn.Click += new System.EventHandler(this.CosBtn_Click);
            // 
            // SevenBtn
            // 
            this.SevenBtn.Location = new System.Drawing.Point(13, 100);
            this.SevenBtn.Name = "SevenBtn";
            this.SevenBtn.Size = new System.Drawing.Size(56, 23);
            this.SevenBtn.TabIndex = 7;
            this.SevenBtn.Text = "7";
            this.SevenBtn.UseVisualStyleBackColor = true;
            this.SevenBtn.Click += new System.EventHandler(this.SevenBtn_Click);
            // 
            // EightBtn
            // 
            this.EightBtn.Location = new System.Drawing.Point(75, 101);
            this.EightBtn.Name = "EightBtn";
            this.EightBtn.Size = new System.Drawing.Size(58, 23);
            this.EightBtn.TabIndex = 8;
            this.EightBtn.Text = "8";
            this.EightBtn.UseVisualStyleBackColor = true;
            this.EightBtn.Click += new System.EventHandler(this.EightBtn_Click);
            // 
            // NineBtn
            // 
            this.NineBtn.Location = new System.Drawing.Point(139, 100);
            this.NineBtn.Name = "NineBtn";
            this.NineBtn.Size = new System.Drawing.Size(51, 23);
            this.NineBtn.TabIndex = 9;
            this.NineBtn.Text = "9";
            this.NineBtn.UseVisualStyleBackColor = true;
            this.NineBtn.Click += new System.EventHandler(this.NineBtn_Click);
            // 
            // FourBtn
            // 
            this.FourBtn.Location = new System.Drawing.Point(13, 130);
            this.FourBtn.Name = "FourBtn";
            this.FourBtn.Size = new System.Drawing.Size(56, 23);
            this.FourBtn.TabIndex = 10;
            this.FourBtn.Text = "4";
            this.FourBtn.UseVisualStyleBackColor = true;
            this.FourBtn.Click += new System.EventHandler(this.FourBtn_Click);
            // 
            // FiveBtn
            // 
            this.FiveBtn.Location = new System.Drawing.Point(75, 131);
            this.FiveBtn.Name = "FiveBtn";
            this.FiveBtn.Size = new System.Drawing.Size(58, 23);
            this.FiveBtn.TabIndex = 11;
            this.FiveBtn.Text = "5";
            this.FiveBtn.UseVisualStyleBackColor = true;
            this.FiveBtn.Click += new System.EventHandler(this.FiveBtn_Click);
            // 
            // SixBtn
            // 
            this.SixBtn.Location = new System.Drawing.Point(139, 131);
            this.SixBtn.Name = "SixBtn";
            this.SixBtn.Size = new System.Drawing.Size(51, 23);
            this.SixBtn.TabIndex = 12;
            this.SixBtn.Text = "6";
            this.SixBtn.UseVisualStyleBackColor = true;
            this.SixBtn.Click += new System.EventHandler(this.SixBtn_Click);
            // 
            // OneBtn
            // 
            this.OneBtn.Location = new System.Drawing.Point(13, 160);
            this.OneBtn.Name = "OneBtn";
            this.OneBtn.Size = new System.Drawing.Size(56, 23);
            this.OneBtn.TabIndex = 13;
            this.OneBtn.Text = "1";
            this.OneBtn.UseVisualStyleBackColor = true;
            this.OneBtn.Click += new System.EventHandler(this.OneBtn_Click);
            // 
            // TwoBtn
            // 
            this.TwoBtn.Location = new System.Drawing.Point(75, 161);
            this.TwoBtn.Name = "TwoBtn";
            this.TwoBtn.Size = new System.Drawing.Size(58, 23);
            this.TwoBtn.TabIndex = 14;
            this.TwoBtn.Text = "2";
            this.TwoBtn.UseVisualStyleBackColor = true;
            this.TwoBtn.Click += new System.EventHandler(this.TwoBtn_Click);
            // 
            // ThreeBtn
            // 
            this.ThreeBtn.Location = new System.Drawing.Point(139, 161);
            this.ThreeBtn.Name = "ThreeBtn";
            this.ThreeBtn.Size = new System.Drawing.Size(51, 23);
            this.ThreeBtn.TabIndex = 15;
            this.ThreeBtn.Text = "3";
            this.ThreeBtn.UseVisualStyleBackColor = true;
            this.ThreeBtn.Click += new System.EventHandler(this.ThreeBtn_Click);
            // 
            // ClearBtn
            // 
            this.ClearBtn.Location = new System.Drawing.Point(13, 190);
            this.ClearBtn.Name = "ClearBtn";
            this.ClearBtn.Size = new System.Drawing.Size(56, 23);
            this.ClearBtn.TabIndex = 16;
            this.ClearBtn.Text = "Clear";
            this.ClearBtn.UseVisualStyleBackColor = true;
            this.ClearBtn.Click += new System.EventHandler(this.ClearBtn_Click);
            // 
            // ZeroBtn
            // 
            this.ZeroBtn.Location = new System.Drawing.Point(75, 190);
            this.ZeroBtn.Name = "ZeroBtn";
            this.ZeroBtn.Size = new System.Drawing.Size(58, 23);
            this.ZeroBtn.TabIndex = 17;
            this.ZeroBtn.Text = "0";
            this.ZeroBtn.UseVisualStyleBackColor = true;
            this.ZeroBtn.Click += new System.EventHandler(this.ZeroBtn_Click);
            // 
            // DotBtn
            // 
            this.DotBtn.Location = new System.Drawing.Point(139, 190);
            this.DotBtn.Name = "DotBtn";
            this.DotBtn.Size = new System.Drawing.Size(51, 23);
            this.DotBtn.TabIndex = 18;
            this.DotBtn.Text = ".";
            this.DotBtn.UseVisualStyleBackColor = true;
            this.DotBtn.Click += new System.EventHandler(this.DotBtn_Click);
            // 
            // PlusBtn
            // 
            this.PlusBtn.Location = new System.Drawing.Point(197, 40);
            this.PlusBtn.Name = "PlusBtn";
            this.PlusBtn.Size = new System.Drawing.Size(53, 23);
            this.PlusBtn.TabIndex = 19;
            this.PlusBtn.Text = "+";
            this.PlusBtn.UseVisualStyleBackColor = true;
            this.PlusBtn.Click += new System.EventHandler(this.PlusBtn_Click);
            // 
            // MinusBtn
            // 
            this.MinusBtn.Location = new System.Drawing.Point(197, 70);
            this.MinusBtn.Name = "MinusBtn";
            this.MinusBtn.Size = new System.Drawing.Size(53, 23);
            this.MinusBtn.TabIndex = 20;
            this.MinusBtn.Text = "-";
            this.MinusBtn.UseVisualStyleBackColor = true;
            this.MinusBtn.Click += new System.EventHandler(this.MinusBtn_Click);
            // 
            // DivideBtn
            // 
            this.DivideBtn.Location = new System.Drawing.Point(197, 100);
            this.DivideBtn.Name = "DivideBtn";
            this.DivideBtn.Size = new System.Drawing.Size(53, 23);
            this.DivideBtn.TabIndex = 21;
            this.DivideBtn.Text = "/";
            this.DivideBtn.UseVisualStyleBackColor = true;
            this.DivideBtn.Click += new System.EventHandler(this.DivideBtn_Click);
            // 
            // TimesBtn
            // 
            this.TimesBtn.Location = new System.Drawing.Point(197, 130);
            this.TimesBtn.Name = "TimesBtn";
            this.TimesBtn.Size = new System.Drawing.Size(53, 23);
            this.TimesBtn.TabIndex = 22;
            this.TimesBtn.Text = "*";
            this.TimesBtn.UseVisualStyleBackColor = true;
            this.TimesBtn.Click += new System.EventHandler(this.TimesBtn_Click);
            // 
            // EqualsBtn
            // 
            this.EqualsBtn.Location = new System.Drawing.Point(197, 161);
            this.EqualsBtn.Name = "EqualsBtn";
            this.EqualsBtn.Size = new System.Drawing.Size(53, 52);
            this.EqualsBtn.TabIndex = 23;
            this.EqualsBtn.Text = "=";
            this.EqualsBtn.UseVisualStyleBackColor = true;
            this.EqualsBtn.Click += new System.EventHandler(this.EqualsBtn_Click);
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(267, 234);
            this.Controls.Add(this.EqualsBtn);
            this.Controls.Add(this.TimesBtn);
            this.Controls.Add(this.DivideBtn);
            this.Controls.Add(this.MinusBtn);
            this.Controls.Add(this.PlusBtn);
            this.Controls.Add(this.DotBtn);
            this.Controls.Add(this.ZeroBtn);
            this.Controls.Add(this.ClearBtn);
            this.Controls.Add(this.ThreeBtn);
            this.Controls.Add(this.TwoBtn);
            this.Controls.Add(this.OneBtn);
            this.Controls.Add(this.SixBtn);
            this.Controls.Add(this.FiveBtn);
            this.Controls.Add(this.FourBtn);
            this.Controls.Add(this.NineBtn);
            this.Controls.Add(this.EightBtn);
            this.Controls.Add(this.SevenBtn);
            this.Controls.Add(this.CosBtn);
            this.Controls.Add(this.SinBtn);
            this.Controls.Add(this.TanBtn);
            this.Controls.Add(this.InvBtn);
            this.Controls.Add(this.CubeRTBtn);
            this.Controls.Add(this.SQRTBtn);
            this.Controls.Add(this.DisplayBox);
            this.Name = "Calculator";
            this.Text = "Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox DisplayBox;
        private System.Windows.Forms.Button SQRTBtn;
        private System.Windows.Forms.Button CubeRTBtn;
        private System.Windows.Forms.Button InvBtn;
        private System.Windows.Forms.Button TanBtn;
        private System.Windows.Forms.Button SinBtn;
        private System.Windows.Forms.Button CosBtn;
        private System.Windows.Forms.Button SevenBtn;
        private System.Windows.Forms.Button EightBtn;
        private System.Windows.Forms.Button NineBtn;
        private System.Windows.Forms.Button FourBtn;
        private System.Windows.Forms.Button FiveBtn;
        private System.Windows.Forms.Button SixBtn;
        private System.Windows.Forms.Button OneBtn;
        private System.Windows.Forms.Button TwoBtn;
        private System.Windows.Forms.Button ThreeBtn;
        private System.Windows.Forms.Button ClearBtn;
        private System.Windows.Forms.Button ZeroBtn;
        private System.Windows.Forms.Button DotBtn;
        private System.Windows.Forms.Button PlusBtn;
        private System.Windows.Forms.Button MinusBtn;
        private System.Windows.Forms.Button DivideBtn;
        private System.Windows.Forms.Button TimesBtn;
        private System.Windows.Forms.Button EqualsBtn;
    }
}

